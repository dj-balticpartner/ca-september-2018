<?php
header('Content-Type: application/json');

if(isset($_POST["user"]) && $_POST["user"] === 'Jonas' && isset($_POST["pass"]) && $_POST["pass"] === 'test'){
echo json_encode([
    "status" => 'OK',
	"msg" => "welcomen"
   ]);
} else {
	echo json_encode([
    "status" => 'Problem',
	"msg" => "access denied",
	"user" => $_POST["user"],
	"pass" => $_POST["pass"]
   ]);
}